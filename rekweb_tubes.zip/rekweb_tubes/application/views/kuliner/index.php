<div class="container">
    <div class="flash-data" data-flashdata="<?= $this->session->flashdata('flash'); ?>"></div>
    
    <div class="row mt-3">
        <div class="col-md-6">
            <a href="<?= base_url(); ?>kuliner/tambah" class="btn btn-primary">Tambah Data Kuliner</a>
        </div>
    </div>

    <div class="row mt-3">
        <div class="col-md-8">
            <h3>Daftar Kuliner</h3>
            <div class="row mt-3">
                <div class="col-md-6">
                    <form action="<?= base_url('kuliner'); ?>" method="post">
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="Cari Data Kuliner" name="keyword" autocomplete="off" autofocus>
                            <div class="input-group-append">
                                <input class="btn btn-primary" type="submit" name="submit">
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            
            <h5 class="mt-3">Hasil : <?= $total_rows; ?></h5>
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Nama</th>
                        <th>Daerah</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if(empty($kuliner)) : ?>
                        <tr>
                            <th colspan="4" class="text-center">
                                <div class="alert alert-danger mt-3" role="alert">
                                    Data Kuliner Tidak Ditemukan
                                </div>
                            </th>
                        </tr>
                    <?php endif; ?>
                    <?php foreach($kuliner as $k) : ?>
                    <tr>
                        <th><?= ++$start; ?></th>
                        <td><?= $k['nama_kuliner']; ?></td>
                        <td><?= $k['daerah_kuliner']; ?></td>
                        <td>
                            <a href="<?= base_url(); ?>kuliner/detail/<?= $k['id_kuliner']; ?>" class="btn btn-primary">Detail</a>
                            <a href="<?= base_url(); ?>kuliner/ubah/<?= $k['id_kuliner']; ?>" class="btn btn-success">Ubah</a>
                            <a href="<?= base_url(); ?>kuliner/hapus/<?= $k['id_kuliner']; ?>" class="btn btn-danger tombol-hapus">Hapus</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
            <?= $this->pagination->create_links(); ?>
        </div>
    </div>
</div>