<div class="container">
    <div class="row mt-3">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    Form Tambah Data Kuliner
                </div>
                <div class="card-body">
                    <?= form_open_multipart('Kuliner/tambah'); ?>
                        <div class="form-group mb-3">
                            <label for="nama_kuliner" class="form-label">Nama Kuliner</label>
                            <input type="text" name="nama_kuliner" class="form-control" id="nama_kuliner">
                            <small class="form-text text-danger"><?= form_error('nama_kuliner'); ?></small>
                        </div>
                        <div class="form-group mb-3">
                            <label for="daerah_kuliner" class="form-label">Daerah Kuliner</label>
                            <input type="text" name="daerah_kuliner" class="form-control" id="daerah_kuliner">
                            <small class="form-text text-danger"><?= form_error('daerah_kuliner'); ?></small>
                        </div>
                        <div class="form-group mb-3">
                            <label for="deskripsi_kuliner" class="form-label">Deskripsi Kuliner</label>
                            <textarea type="text" class="form-control" id="deskripsi_kuliner" name="deskripsi_kuliner" rows="10"></textarea>
                            <small class="form-text text-danger"><?= form_error('deskripsi_kuliner'); ?></small>
                        </div>
                        <div class="form-group mb-3">
                            <label for="gambar_kuliner" class="form-label">Gambar Kuliner</label>
                            <input type="file" name="gambar_kuliner" class="form-control"  id="gambar_kuliner">
                            <small class="form-text text-danger"><?= form_error('gambar_kuliner'); ?></small>
                        </div>
                        <div>
                            <button type="submit" name="tambah" class="btn btn-primary float-end">Tambah Data</button>
                        </div>
                    <?= form_close(); ?>
                </div>
            </div>
        </div>
    </div>
</div>