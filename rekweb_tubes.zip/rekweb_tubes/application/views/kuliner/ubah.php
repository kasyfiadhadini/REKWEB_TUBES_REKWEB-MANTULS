<div class="container">
    <div class="row mt-3">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header">
                    Form Ubah Data Kuliner
                </div>
                <div class="card-body">
                    <form action="" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="id_kuliner" value="<?= $kuliner['id_kuliner']; ?>">
                        <div class="form-group mb-3">
                            <label for="nama_kuliner" class="form-label">Nama Kuliner</label>
                            <input type="text" name="nama_kuliner" class="form-control" id="nama_kuliner" value="<?= $kuliner['nama_kuliner']; ?>">
                            <small class="form-text text-danger"><?= form_error('nama_kuliner'); ?></small>
                        </div>
                        <div class="form-group mb-3">
                            <label for="daerah_kuliner" class="form-label">Daerah Kuliner</label>
                            <input type="text" name="daerah_kuliner" class="form-control" id="daerah_kuliner" value="<?= $kuliner['daerah_kuliner']; ?>">
                            <small class="form-text text-danger"><?= form_error('daerah_kuliner'); ?></small>
                        </div>
                        <div class="form-group mb-3">
                            <label for="deskripsi_kuliner" class="form-label">Deskripsi Kuliner</label>
                            <textarea class="form-control" id="deskripsi_kuliner" name="deskripsi_kuliner" rows="10"><?= $kuliner['deskripsi_kuliner']; ?></textarea>
                            <small class="form-text text-danger"><?= form_error('deskripsi_kuliner'); ?></small>
                        </div>
                        <div class="form-group mb-3">
                            <label for="gambar_kuliner" class="form-label">Gambar Kuliner</label>
                            <input type="file" name="gambar_kuliner" class="form-control" id="gambar_kuliner" value="<?= $kuliner['gambar_kuliner']; ?>">
                            <small class="form-text text-danger"><?= form_error('gambar_kuliner'); ?></small>
                        </div>
                        <img src="<?= base_url() . '/assets/img/kuliner/' . $kuliner['gambar_kuliner']; ?>" width="107">
                        <div>
                            <button type="submit" name="ubah" class="btn btn-primary float-end">Ubah Data</button>
                        </div>
                    </form> 
                </div>
            </div>
        </div>
    </div>
</div>