<?php
function get_CURL($url) 
{
  $curl = curl_init();
  curl_setopt($curl, CURLOPT_URL, $url);
  curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
  $result = curl_exec($curl);
  curl_close($curl);

  return json_decode($result, true);
}

  $result = get_CURL('https://www.googleapis.com/youtube/v3/channels?part=snippet,statistics&id=UCf7Y3Lczxf2-5x7Okhg1UCw&key=AIzaSyB-Jrl3T7Mu1FYJFlIRFQrSxgAqTZC0HwM');

  $youtubeProfilePic = $result['items'][0]['snippet']['thumbnails']['medium']['url'];
  $channelName = $result['items'][0]['snippet']['title'];
  $subscriber = $result['items'][0]['statistics']['subscriberCount'];

  // latest video
  $urlLatestVideo = 'https://www.googleapis.com/youtube/v3/search?key=AIzaSyB-Jrl3T7Mu1FYJFlIRFQrSxgAqTZC0HwM&channelId=UCf7Y3Lczxf2-5x7Okhg1UCw&maxResults=1&order=date&part=snippet';
  $result = get_CURL($urlLatestVideo);
  $latestVideoId = $result['items'][0]['id']['videoId'];
?>

<div class="container">
  <div class="row mt-3">
    <div class="col-md-4">
      <h1>All Kuliner</h1>
    </div>
  </div>

  <div class="row mt-3">
    <?php foreach($kuliner as $k) : ?>
      <div class="col-md-4">
        <div class="card mb-3">
          <img src="../assets/img/kuliner/<?= $k['gambar_kuliner'] ?>" class="card-img-top">
          <div class="card-body">
            <h5 class="card-title"><?= $k['nama_kuliner'] ?></h5>
            <h5 class="card-title"><?= $k['daerah_kuliner'] ?></h5>
            <a href="<?= base_url(); ?>home/detail_user/<?= $k['id_kuliner']; ?>" class="btn btn-primary">Detail</a>
          </div>
        </div>
      </div>
    <?php endforeach; ?>
  </div>

  <!-- Youtube -->
  <section class="social-media bg-light" id="social-media">
      <div class="container">
        <div class="row pt-4 mb-4">
          <div class="col text-center">
            <h2>Youtube</h2>
          </div>
        </div>
        <div class="row justify-content-center">
          <div class="col-md-3">
            <div class="row" style="padding-left:30px;">
              <div class="col-md-4">
                <img src="<?= $youtubeProfilePic ?>" width="200" class="rounded-circle img-thumbnail">
              </div>

              <div class="col-md-8">
                <h5><?= $channelName ?></h5>
                <p><?= $subscriber ?> Subcribers.</p> 
                <div class="g-ytsubscribe" data-channelid="UCR-xtog9RWSG0EWC3Cj_JCg" data-layout="default" data-count="default">
                </div>
              </div>
            </div>
            <div class="row mt-3 pb-3">
              <div class="col">
                <div class="embed-responsive embed-responsive-16by9">
                <iframe class="embed-responsive-item" src="https://www.youtube.com/embed/<?=  $latestVideoId ?>?rel=0" allowfullscreens></iframe>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>

</div>