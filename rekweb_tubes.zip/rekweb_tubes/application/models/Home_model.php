<?php

class Home_model extends CI_model {

    public function getAllKuliner()
    {
        return $this->db->get('kuliner')->result_array();
    }
    
    public function getKulinerById($id)
    {
        return $this->db->get_where('kuliner', ['id_kuliner' => $id])->row_array();
    }
}

?>