<?php

class Kuliner_model extends CI_model {
    public function getAllKuliner()
    {
        return $this->db->get('kuliner')->result_array();
    }

    public function getKuliner($limit, $start, $keyword = null)
    {
        if($keyword) {
            $this->db->like('nama_kuliner', $keyword);
            $this->db->or_like('daerah_kuliner', $keyword);
        }
        return $this->db->get('kuliner', $limit, $start)->result_array();
    }

    public function countAllKuliner()
    {
        return $this->db->get('kuliner')->num_rows();
    }

    public function tambahDataKuliner()
    {
        $data = [
            "nama_kuliner" => $this->input->post('nama_kuliner', true),
            "daerah_kuliner" => $this->input->post('daerah_kuliner', true),
            "deskripsi_kuliner" => $this->input->post('deskripsi_kuliner', true),
            "gambar_kuliner" => $this->upload->data('file_name', true)
        ];
        $this->db->insert('kuliner', $data);
    }

    public function hapusDataKuliner($id)
    {
        //$this->db->where('id', $id);
        $this->db->delete('kuliner', ['id_kuliner' => $id]);
    }

    public function getKulinerById($id)
    {
        return $this->db->get_where('kuliner', ['id_kuliner' => $id])->row_array();
    }

    public function ubahDataKuliner1()
    {
        $data = [
            "nama_kuliner" => $this->input->post('nama_kuliner', true),
            "daerah_kuliner" => $this->input->post('daerah_kuliner', true),
            "deskripsi_kuliner" => $this->input->post('deskripsi_kuliner', true),
        ];
        $this->db->where('id_kuliner', $this->input->post('id_kuliner'));
        $this->db->update('kuliner', $data);
    }

    public function ubahDataKuliner2()
    {
        $data = [
            "nama_kuliner" => $this->input->post('nama_kuliner', true),
            "daerah_kuliner" => $this->input->post('daerah_kuliner', true),
            "deskripsi_kuliner" => $this->input->post('deskripsi_kuliner', true),
            "gambar_kuliner" => $this->upload->data('file_name', true)
        ];
        $this->db->where('id_kuliner', $this->input->post('id_kuliner'));
        $this->db->update('kuliner', $data);
    }
}