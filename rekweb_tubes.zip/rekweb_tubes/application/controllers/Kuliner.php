<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Kuliner extends CI_Controller {
	public function __construct()
	{
		parent::__construct();
		$this->load->model('Kuliner_model');
		$this->load->library('form_validation');
	}

	public function index()
	{
		$data['judul'] = 'Daftar Kuliner';
		// $data['kuliner'] = $this->Kuliner_model->getAllKuliner();\
		
		// Load library
		$this->load->library('pagination');
		
		// Ambil data keyword
		if($this->input->post('submit')) {
			$data['keyword'] = $this->input->post('keyword');
			$this->session->set_userdata('keyword', $data['keyword']);
		} else {
			$data['keyword'] = $this->session->userdata('keyword');
		}

		// Config
		$this->db->like('nama_kuliner', $data['keyword']);
		$this->db->or_like('daerah_kuliner', $data['keyword']);
		$this->db->from('kuliner');
		$config['total_rows'] = $this->db->count_all_results();
		$data['total_rows'] = $config['total_rows'];
		$config['per_page'] = 5;

		// Initialize
		$this->pagination->initialize($config);
		$data['start'] = $this->uri->segment(3);
		$data['kuliner'] = $this->Kuliner_model->getKuliner($config['per_page'], $data['start'], $data['keyword']);
		
		$this->load->view('layouts/header', $data);
	    $this->load->view('kuliner/index', $data);
   		$this->load->view('layouts/footer');
	}

	public function tambah()
	{
		$data['judul'] = 'Form Tambah Data Kuliner';
		$this->form_validation->set_rules('nama_kuliner', 'Nama', 'required');
		$this->form_validation->set_rules('daerah_kuliner', 'Daerah', 'required');
		$this->form_validation->set_rules('deskripsi_kuliner', 'Deskripsi', 'required');
		$this->form_validation->set_rules('gambar_kuliner', 'Gambar', 'required');
		
		$config['upload_path']          = './assets/img/kuliner';
        $config['allowed_types']        = 'gif|jpg|png|jpeg';
        $config['max_size']             = 2048;

		$this->load->library('upload', $config);

		if (! $this->upload->do_upload('gambar_kuliner')) {
			if ($this->form_validation->run() == FALSE) {
				$this->load->view('layouts/header', $data);
				$this->load->view('kuliner/tambah', $data);
				$this->load->view('layouts/footer_home');
			}
		} else {
			$this->Kuliner_model->tambahDataKuliner();
			$this->session->set_flashdata('flash', 'Ditambahkan');
			redirect('kuliner');	
		}
	}

	public function hapus($id)
	{
		$this->Kuliner_model->hapusDataKuliner($id);
		$this->session->set_flashdata('flash', 'Dihapus');
		redirect('kuliner');
	}

	public function detail($id)
	{
		$data['judul'] = 'Detail Data Kuliner';
		$data['kuliner'] = $this->Kuliner_model->getKulinerById($id);
		$this->load->view('layouts/header', $data);
	    $this->load->view('kuliner/detail');
   		$this->load->view('layouts/footer_home');
	}

	public function ubah($id)
	{
		$data['judul'] = 'Form Ubah Data Kuliner';
		$data['kuliner'] = $this->Kuliner_model->getKulinerById($id);
		$this->form_validation->set_rules('nama_kuliner', 'Nama', 'required');
		$this->form_validation->set_rules('daerah_kuliner', 'Daerah', 'required');
		$this->form_validation->set_rules('deskripsi_kuliner', 'Deskripsi', 'required');
		$this->form_validation->set_rules('gambar_kuliner', 'Gambar');

		$config['upload_path']          = './assets/img/kuliner';
        $config['allowed_types']        = 'gif|jpg|png|jpeg';
        $config['max_size']             = 5000;

		$this->load->library('upload', $config);

		if (! $this->upload->do_upload('gambar_kuliner')) {
			if ($this->form_validation->run() == FALSE) {
				$this->load->view('layouts/header', $data);
				$this->load->view('kuliner/ubah', $data);
				$this->load->view('layouts/footer_home');
			} else {
				$this->Kuliner_model->ubahDataKuliner1();
				$this->session->set_flashdata('flash', 'Diubah');
				redirect('kuliner');
			}
		} else {
			$this->Kuliner_model->ubahDataKuliner2();
			$this->session->set_flashdata('flash', 'Diubah');
			redirect('kuliner');	
		}
	}
}